// Mongoose model for Property
