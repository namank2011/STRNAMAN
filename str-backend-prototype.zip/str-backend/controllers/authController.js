// Handle register/login logic
