// JWT auth middleware
