// Mongoose model for User
