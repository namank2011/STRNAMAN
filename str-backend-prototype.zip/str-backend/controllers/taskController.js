// Manage cleaning tasks
