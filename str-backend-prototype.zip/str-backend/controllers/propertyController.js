// CRUD for properties
