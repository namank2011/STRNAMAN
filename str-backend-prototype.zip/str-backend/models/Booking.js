// Mongoose model for Booking
