// Handle booking logic and auto-task creation
