// Entry point for server
